package com.example.layouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.database.DatabaseUtils;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.layouts.data.Bio;
import com.example.layouts.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binder;

    private Bio aayush = new Bio();
    private EditText hobbies;
    private TextView entered_hobbies;
    private Button press;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        binder = DataBindingUtil.setContentView(this, R.layout.activity_main);
        /* layouts enable views or widgets to display in a specific manner
        whatever is on the screen is a view, it inherits from the view class
            view group can contain other view components=
        */

        //we also dont need to do findViewbyid..
        hobbies = findViewById(R.id.editTextTextPersonName2);
        entered_hobbies = findViewById(R.id.textView8);
        press = findViewById(R.id.button2);
        /*find view by id is an expensive operation, android internally has to traverse through all the ids to get the correct one
        // so we use Data Binding - we have an intermediary object called the binding object then we call that binding object in our activity
        // how to use data binding - in the module gradle add buildFeatures{dataBinding true}
        next open up xml code and add <layout + xmlns:android= "copy whatever was there from the previous layout and refactor">
        create binding object ActivityMainBinding obj_name

        then we would not need  SetContentView....
        just setup the binding object there

        */
        //instead of press we can use binder.id
        aayush.setName("Aayush Dubey");
        aayush.setHobbies("ndo champ");
        binder.setAayush(aayush);

        binder.button2.setOnClickListener(View -> {
            binder.textView8.setText(binder.editTextTextPersonName2.getText().toString().trim());
            binder.textView8.setVisibility(View.VISIBLE);
            //getting rid of the keyboard once we are done

            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(View.getWindowToken(), 0);

        });

    }
}