package com.example.quizr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;
import android.util.Log;

import com.example.quizr.databinding.ActivityMainBinding;
import com.example.quizr.model.Question;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private Question[] questionBank = new Question[]{
            new Question(R.string.ques1,true),
            new Question(R.string.ques2,true),
            new Question(R.string.ques3,false),
            new Question(R.string.ques4,false),
            new Question(R.string.ques5, true)
            //res id is being passed as an integer, the resource id is an integer
    };
    private int questionIndex = 0;
    private ActivityMainBinding binder;
    private boolean answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*building this quiz app following the model view controller architecture
         model is the data part of our application in this app the questions will be the model
         the controller is the main activity
         and the views are the layouts which we see on the screen
         we use mvc so that if we want to change one layer, it is not going to affect the other layer


         with the help of a constrain layout the buttons or views will show up at the same place in any screen size
        */

        //setup binding object, this is view binding
        binder = DataBindingUtil.setContentView(this,R.layout.activity_main);
        binder.question.setText(questionBank[questionIndex].getQuestionId());
        //binder.question.setText(questionBank[questionIndex].getAnswerId()); //setting view elements to see if view binding works
        binder.next.setOnClickListener(view -> {
            questionIndex = (questionIndex+1)%questionBank.length;
            Log.d("Main","current index value " + questionIndex);
            binder.question.setText(questionBank[questionIndex].getQuestionId());
//            answer = questionBank[questionIndex].answer();

        });
        binder.tru.setOnClickListener(view -> {
            answer = true;
            if(answer == questionBank[questionIndex].answer())
            {
                Snackbar.make(view,"correct answer",Snackbar.LENGTH_SHORT).show();
            }
            else
            {
                Snackbar.make(view,"wrong answer",Snackbar.LENGTH_SHORT).show();

            }
        });
        binder.fal.setOnClickListener(view -> {
            answer = false;
            if(answer == questionBank[questionIndex].answer())
            {
                Snackbar.make(view,"correct answer",Snackbar.LENGTH_SHORT).show();
            }
            else
            {
                Snackbar.make(view,"wrong answer",Snackbar.LENGTH_SHORT).show();

            }
        });
        binder.previous.setOnClickListener(view -> {
            questionIndex = (questionIndex+4)% questionBank.length;
             binder.question.setText(questionBank[questionIndex].getQuestionId());


        });
    }
}