package com.example.quizr.model;

public class Question {
    private int questionId;
    private boolean answer;

    public int getQuestionId() {
        return questionId;
    }

    public void setAnswerId(int questionId) {
        this.questionId = questionId;
    }

    public boolean answer() {
        return answer;
    }

    public void setAnswerTrue(boolean answerTrue) {
        this.answer = answerTrue;
    }

    public Question(int questionId, boolean answerTrue) {
        this.questionId = questionId;
        this.answer = answerTrue;
    }
}
