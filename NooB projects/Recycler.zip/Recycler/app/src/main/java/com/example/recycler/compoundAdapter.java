package com.example.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class compoundAdapter extends RecyclerView.Adapter<compoundAdapter.MyViewHolder > {

    private  Context context;
    private  ArrayList<CompoundClass> comps;

    //MyViewHolder will be an inner class

    //we need to create a constructor that will have the data that we require in the cards

    public compoundAdapter(Context context, ArrayList<CompoundClass> comps){
        this.context = context;
        this.comps = comps;
    }
    @NonNull
    @Override
    public compoundAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //this method inflates the layout and calls the rows/card to the recycler view
        //after setting data in on bind, its time to inflate the layout

        LayoutInflater inflator = LayoutInflater.from(context);
        View view = inflator.inflate(R.layout.compound_card,parent,false);

        return new compoundAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull compoundAdapter.MyViewHolder holder, int position) {
        // this is where we assign values to each of the cards as they come back to the screen
        holder.txt.setText(comps.get(position).getName());
        holder.txt3.setText(comps.get(position).name_three);
        holder.img.setImageResource(comps.get(position).getImage_id());

    }

    @Override
    public int getItemCount() {
        //the number of items being displayed
        return comps.size();
    }
    //it has to be static - You cannot use the static keyword with a class unless it is an inner class.
    // A static inner class is a nested class which is a static member of the outer class.
    //To access static methods there is no need to instantiate the class,
    public static class MyViewHolder extends RecyclerView.ViewHolder{
//this class is like the oncreate method in mainActivity
        //we grab the cards here and we set values

        //we hae 1 image view and 2 text views
        ImageView img;
        TextView txt,txt3;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            img = itemView.findViewById(R.id.imageView); // don't forget view parameter itemview
            txt = itemView.findViewById(R.id.full);
            txt3 = itemView.findViewById(R.id.abbr);






        }
    }
}
