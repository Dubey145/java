package com.example.recycler;

public class CompoundClass {
    String name;
    String name_three;
    int image_id;

    public CompoundClass(String name, String name_three, int image_id) {
        this.name = name;
        this.name_three = name_three;
        this.image_id = image_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName_three() {
        return name_three;
    }

    public void setName_three(String name_three) {
        this.name_three = name_three;
    }

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }
}
