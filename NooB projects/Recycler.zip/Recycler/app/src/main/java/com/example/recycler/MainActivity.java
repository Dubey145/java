package com.example.recycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<CompoundClass> comp = new ArrayList<>();
    RecyclerView comp_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create adapter after object setup;
        objectSetup();
        //time to attach our adapter to our recycler view
        comp_list = findViewById(R.id.compound_list);

        compoundAdapter adapter = new compoundAdapter(this,comp);

        comp_list.setAdapter(adapter);
        comp_list.setLayoutManager(new LinearLayoutManager(this));



    }
    private void objectSetup(){
        String[] compoundNames = getResources().getStringArray(R.array.compounds);
        String[] compoundThree = getResources().getStringArray(R.array.compounds_three);
        int[] imageArray = {R.drawable.ic__toulene,R.drawable.ic_amino_acid_general,R.drawable.ic_glutamine,R.drawable.ic_glycine,R.drawable.ic_isoleucine,R.drawable.ic_serine,R.drawable.ic_tyrosine};

        //loop through the array and save the data in an object
        for(int i = 0 ;i<compoundNames.length;i++){
            //making multiple objects here
            comp.add(new CompoundClass(compoundNames[i],compoundThree[i],imageArray[i]));
        }


    }
}