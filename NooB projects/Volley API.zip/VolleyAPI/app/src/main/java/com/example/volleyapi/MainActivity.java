package com.example.volleyapi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    RequestQueue queue; // queues up all the requests
    TextView id,title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id = findViewById(R.id.userid);
        title = findViewById(R.id.title);
        final int[] i = {0};

        queue = Volley.newRequestQueue(this); // it will q all the fetched data
        String url = "https://jsonplaceholder.typicode.com/todos"; // where to get the data from

        StringRequest stringRequest = getStringRequest(url);

        //adding request to the request queue object
        queue.add(stringRequest);

        JsonArrayRequest json = new JsonArrayRequest(Request.Method.GET,url,null, response->{
            //we now have the response array, it is an array of json objects
            while(i[0] <response.length()){
                try {
                    JSONObject obj = response.getJSONObject(i[0]);
                    title.setText(obj.getString("title"));
                    id.setText(obj.getString("userId"));
                    Log.d("main","OnCreate " + obj.getString("title"));
                    i[0]++;

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },error->{
            Log.d("JSON","OnCreate : Failed");
        });
        queue.add(json);


        String newurl = "https://jsonplaceholder.typicode.com/todos/1"; // to access the first -> /1
        //accessing just one object

        JsonObjectRequest jay = new JsonObjectRequest(Request.Method.GET,newurl,null, response->{

            try {
                Log.d("object","tt " + response.getString("title"));
                title.setText(response.getString("title"));
                id.setText(response.getString("userId"));
            } catch (JSONException e) {
                e.printStackTrace();
            }


        },error->{
            Log.d("JS0N","OnCreate : Failed");
        });

        queue.add(jay);
        //the problem with request queue is that we have to add each object to it when we create a json object
        /*

        singleton
        sometimes we only need one object
        singleton ensures that we only have one instance of a class and it provides global access






         */

    }

    @NonNull
    private StringRequest getStringRequest(String url) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //display contents of the url
                Log.d("main","onCreate"+ response.substring(0,500));
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // what to do if an error occurs
                Log.d("main","no info");

            }
        });
        return stringRequest;
    }
}









