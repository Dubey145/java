package com.example.listviews;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class fruitAdapter extends BaseAdapter {

    String[] fruits;
    int[] images;
    LayoutInflater layoutInflater;

    public fruitAdapter(Context context, String[] fruits, int [] images){
            this.fruits = fruits;
            this.images = images;
            layoutInflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return fruits.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.viewcard,null); // view is the view that we want to inflate /get

        TextView txt =(TextView)view.findViewById(R.id.card_text); // link ids of that view here
        ImageView img =  (ImageView)view.findViewById(R.id.card_image);

        txt.setText(fruits[i]); // set the rquired data
        img.setImageResource(images[i]);

        return view;
    }
}
