package com.example.listviews;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //listView is just a list of data, it is not the same as recycler view

    //we'll need a data source for our list , lets take this array
    private ArrayList<String> items = new ArrayList<>();
    private ListView listView;

    private  String[] fruits = {"apple","avacado","guava","kiwi","orange","pineapple","strawberry"};
    private  int[] images = {R.drawable.apple,R.drawable.avacado,R.drawable.guava,R.drawable.kiwi,R.drawable.orange,R.drawable.pineapple,R.drawable.strawberry};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list);

        items.add("complete job 1");
        items.add("complete job 2");
        items.add("complete job 3");
        items.add("complete job 4");
        items.add("complete job 5");
        items.add("complete job 6");

        // now we have to make an adapter
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,items);
        listView.setAdapter(arrayAdapter);

//        listView.setOnItemClickListener((adapterView, view, i, l) -> { // syntax and arguments are different for item click i is the position and l is id
//            String message = "item : " + i + " " + ((TextView)view).getText().toString() ;
//            Toast.makeText(getApplicationContext(),message, Toast.LENGTH_SHORT).show();
//        });

        //making a custom list view adapter -- > made in class fruitAdapter

        //initialize the custom adapter
        fruitAdapter custom_fruit_adapter = new fruitAdapter(this,fruits,images);
        listView.setAdapter(custom_fruit_adapter);

        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            //String message = "item : " + i + " " + ((TextView)view).getText().toString() ;
            Toast.makeText(getApplicationContext(),"item tapped : " + fruits[i], Toast.LENGTH_SHORT).show();
        });

    }
}