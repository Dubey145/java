package com.example.sharedprefs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String MESSAGE_ID = "message_prefs";
    // whenever we save small amounts of data we do so using shared preferences
    private Button button;
    private EditText editText;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btn);
        editText = findViewById(R.id.edt);
        textView = findViewById(R.id.textv);

        button.setOnClickListener(view -> {
            String message = editText.getText().toString().trim();

            SharedPreferences sp = getSharedPreferences(MESSAGE_ID,MODE_PRIVATE); // shared preferences is an xml so we need an id for it, mode can limit the access from other apps
            SharedPreferences.Editor editor = sp.edit(); // editor is like a hash map it will store key value pairs
            editor.putString("message",message);
            editor.apply(); // saving to disk

            //The text view value does not change on click but when we reopen the app the changes reflect
            //as outside the on click listened we are accessing the shared preferences xml
        });
        SharedPreferences get_sp = getSharedPreferences(MESSAGE_ID,MODE_PRIVATE);
        String value = get_sp.getString("message","default value"); // we have to pass the key and if its not found we have to pass a default value

        textView.setText(value);
    }
}











