package com.example.flash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Switch toggle;
    private boolean hasCameraFlash = false;
    private boolean flashOn = false;

//system services

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggle = findViewById(R.id.switch1);

        hasCameraFlash = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        toggle.setOnClickListener(view -> {
            if(hasCameraFlash){
                if(flashOn){
                    flashOn = false;
                    try {
                        flashOFF();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }else{
                    flashOn = true;
                    try {
                        flashON();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
            }else{
                Toast.makeText(MainActivity.this,"no flash available",Toast.LENGTH_LONG).show();
            }
        });

    }

    private void flashON() throws CameraAccessException {
        CameraManager cam = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        //get the camera with the flash
        String camId = cam.getCameraIdList()[0];
        cam.setTorchMode(camId,true);
        Toast.makeText(MainActivity.this,"flash on",Toast.LENGTH_SHORT).show();
    }

    private void flashOFF() throws CameraAccessException {
        CameraManager cam = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        //get the camera with the flash
        String camId = cam.getCameraIdList()[0];
        cam.setTorchMode(camId,false);
        Toast.makeText(MainActivity.this,"flash off",Toast.LENGTH_SHORT).show();
    }
}