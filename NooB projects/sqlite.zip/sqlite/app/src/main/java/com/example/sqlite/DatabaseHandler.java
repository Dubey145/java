package com.example.sqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHandler extends SQLiteOpenHelper {
    public DatabaseHandler(@Nullable Context context) {
        super(context, "contact_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE details(phone TEXT PRIMARY KEY, name TEXT, dob TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS details");
        onCreate(db);
    }
    public boolean addContact(String name, String phone, String dob){

        SQLiteDatabase db = this.getWritableDatabase(); // gets the database on which operations can be performed

        //using content value for data
        ContentValues values = new ContentValues(); //similar to hashmaps but recommended for databases
        //values.put(Util.KEY_ID, contact.getId()); id will be added automatically as it is the primary key
        values.put("phone",phone);
        values.put("name",name);
        values.put("dob",dob);
        //content values class stores key value pairs where keys are the column name

        //Sometimes you want to insert an empty row, in that case ContentValues have no content value, and you should use nullColumnHack.
        //eg For example, you want to insert an empty row into a table student(id, name), which id is auto generated and name is null. You could invoke like this:
        //ContentValues cv = new ContentValues();
        //db.insert("student", "name", cv);

        long result = db.insert("details",null,values);//give the table name and the content value object
        db.close();
        return result != -1;

    }

    public boolean deleteContact(String phone){
        //how to know if the db is ready

        SQLiteDatabase db = this.getWritableDatabase(); // gets the database on which operations can be performed

        //using content value for data
        ContentValues values = new ContentValues(); //similar to hashmaps but recommended for databases
        //we have to create a cursor object which will parse through the db // it will be used to select a row
        @SuppressLint("Recycle")
                //the result of a query will return a cursor object which is used to travel in a db, moveToFirst() move it to the first row and the subsequent rows are accessed by moveToNext()
        Cursor cursor = db.rawQuery("SELECT * FROM details WHERE phone = ?", new String[] {phone}); // when this is executed we will point to the row where we need to updata
        if(cursor.getCount()>0){
            long result = db.delete("details","phone =?",new String[] {phone});//where phone = the string provided that entry will be deleted
            db.close();
            return result != -1;
        }else{
            return false;
        }
    }
    public boolean updateContact(String name, String phone, String dob){
        //how to know if the db is ready

        SQLiteDatabase db = this.getWritableDatabase(); // gets the database on which operations can be performed

        //using content value for data
        ContentValues values = new ContentValues(); //similar to hashmaps but recommended for databases
        //values.put(Util.KEY_ID, contact.getId()); id will be added automatically as it is the primary key

        //we are keeping primary key as the phone number
        values.put("name",name);
        values.put("dob",dob);

        //we have to create a cursor object which will parse through the db // it will be used to select a row
        @SuppressLint("Recycle")
        Cursor cursor = db.rawQuery("SELECT * FROM details WHERE phone = ?", new String[] {phone}); // when this is executed we will point to the row where we need to updata
        if(cursor.getCount()>0){
            long result = db.update("details",values,"phone =?",new String[] {phone});//where phone = the string provided
            if(result == -1){
                db.close();
                return false;
            }
            else{
                db.close();
                return true;
            }
        }else{
            return false;
        }

    }
    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM details",null);
        return cursor;
    }
}
