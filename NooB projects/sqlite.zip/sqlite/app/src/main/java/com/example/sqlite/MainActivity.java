package com.example.sqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    EditText name,phone,dob;
    Button add,delete,update,view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        dob = findViewById(R.id.dob);

        add = findViewById(R.id.add);
        delete = findViewById(R.id.delete);
        update = findViewById(R.id.update);
        view = findViewById(R.id.view);

        DatabaseHandler db = new DatabaseHandler(MainActivity.this);

        add.setOnClickListener(view->{
            boolean result;
            result = db.addContact(name.getText().toString(), phone.getText().toString(), dob.getText().toString());
            if(result){
                Snackbar snack = Snackbar.make(add,"data inserted",Snackbar.LENGTH_SHORT);
                snack.show();
            }
            else{
                Snackbar snack = Snackbar.make(add,"operation failed",Snackbar.LENGTH_SHORT);
                snack.show();
            }
        });
        delete.setOnClickListener(view->{
            if(db.deleteContact(phone.getText().toString())){
                Snackbar snack = Snackbar.make(add,"data deleted",Snackbar.LENGTH_SHORT);
                snack.show();
            }
            else{
                Snackbar snack = Snackbar.make(add,"operation failed",Snackbar.LENGTH_SHORT);
                snack.show();
            }
        });
        update.setOnClickListener(view->{

            if(db.updateContact(name.getText().toString(), phone.getText().toString(), dob.getText().toString())){
                Snackbar snack = Snackbar.make(add,"data updated",Snackbar.LENGTH_SHORT);
                snack.show();
            }
            else{
                Snackbar snack = Snackbar.make(add,"operation failed",Snackbar.LENGTH_SHORT);
                snack.show();
            }
        });

        view.setOnClickListener(view1 -> {
            Cursor res =  db.getData();
            if(res.getCount() == 0){
                Snackbar snack = Snackbar.make(add,"no data",Snackbar.LENGTH_SHORT);
                snack.show();
            }else{
                StringBuilder buffer = new StringBuilder();
                while(res.moveToNext()){
                    buffer.append("name : " +res.getString(0)+"\n");
                    buffer.append("phone : " +res.getString(1)+"\n");
                    buffer.append("dob : " +res.getString(2)+"\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("Database Data");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}