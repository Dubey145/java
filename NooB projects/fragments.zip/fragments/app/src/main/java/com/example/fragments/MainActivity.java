package com.example.fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    Button btn1,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.left);
        btn2 = findViewById(R.id.right);

        btn1.setOnClickListener(view -> {
            replaceFragment(new firstFrag());
        });

        btn2.setOnClickListener(view -> {
            replaceFragment(new secondFragment());
        });
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fm =  getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frame,fragment);
        ft.commit();

    }

    //there are two methods of exchanging data between fragments. one is viewModel the second is using fragment manager
    //if exchanges are frequent use view model
}